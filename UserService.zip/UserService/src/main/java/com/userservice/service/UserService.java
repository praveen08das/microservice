package com.userservice.service;
import java.util.List;

import com.userservice.entity.User;

public interface UserService {
	
	//create
	public User userSave(User user);
	
	//get all user
	List<User>listOfUser();
	
	//get single user of given uerId
	public User getuserId(String id);
	
	

}
