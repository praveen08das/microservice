package com.userservice.service;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.userservice.entity.Hotel;
import com.userservice.entity.Rating;
import com.userservice.entity.User;
import com.userservice.externalservice.HotelService;
import com.userservice.repo.UserRepo;

@Service
public class UserServiceImpl implements UserService {

@Autowired
private UserRepo userRepo;

@Autowired
private RestTemplate restTemplate;

@Autowired
private HotelService hotelService;
	
	@Override  
	public User userSave(User user) {
		
		 String randomUUID = UUID.randomUUID().toString();
		 user.setUserId(randomUUID);
		 User save = userRepo.save(user);
		return save;
	}

	@Override
	public List<User> listOfUser() {
		
		return null;
	}

	@Override
	public User getuserId(String id) {

		User user = userRepo.findById(id).get();
		
		Rating[]  ratingOfUser = restTemplate.getForObject("http://localhost:9004/rating/finduserid/196782a6-400d-4ff1-82de-3162d6f53b1b", Rating[].class);
		        
		List<Rating> raings = Arrays.stream(ratingOfUser).toList();
		
		user.setRating(raings);
		
		 List<Rating> ratingList = raings.stream().map(rating -> 
		{
			
			Hotel hotel = hotelService.getHotel(rating.getHotelId());
			
			rating.setHotel(hotel);
			return rating;
			
		}).collect(Collectors.toList());
		
		user.setRating(ratingList);
		
		return  user;
		
	}

}
