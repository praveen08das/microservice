package com.userservice.exception;



public class ResourceNotFoundException extends RuntimeException {

  public ResourceNotFoundException()
  {
	  
	  super("Resourece not found on server");
	  
  }
	
	
  public ResourceNotFoundException(String measage)
  {  
	  super (measage);
	  
  }
	
  
  
  
	        
	
}
